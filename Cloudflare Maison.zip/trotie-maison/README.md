# TROTIE MAISON

Static Astro storefront served by Cloudflare Workers. A small Worker handles `/api/concierge`.
Everything essential (browse, search, filter, WhatsApp ordering) works without AI.

## Run it
    npm install
    npm run dev        # storefront only; the concierge shows its "unavailable" message here
    npm run preview    # builds, then runs the Worker locally (needs `npx wrangler login`)
    npm run deploy     # builds and publishes to your free workers.dev address

After the first deploy, put the real address in `src/config.mjs` (SITE_URL) and deploy again.
The sitemap, canonical links and robots.txt all use that value.

## Add or edit products
Edit `src/data/products.json`. Put photos in `public/products/` and reference them as
`"images": [{ "src": "/products/name.jpg", "alt": "Describe the watch" }]`.
`npm run check` (also run on every build) fails on missing prices, bad slugs, duplicate ids and so on.
Only add specs (colour, strapMaterial, caseMaterial...) you can verify. Unknown means leave it out.

## Before launch
- Assign each watch its real category (all four start as "everyday").
- Add photos and descriptions.
- Write the shipping, returns, privacy and terms pages from policies the business can honour.
- Set a Cloudflare usage alert; do not add a card or upgrade the plan.

## Deploy from the Cloudflare dashboard (no command line)
1. Create a free GitHub account and a new empty repository. Upload the contents of this folder
   (Add file > Upload files; keep the folder structure, and do not upload node_modules or dist).
2. In Cloudflare: Workers & Pages > Create > Import a repository, and choose it.
3. Build command: `npm run build`. Deploy command: `npx wrangler deploy`. Leave everything else as is.
4. Open the workers.dev address Cloudflare gives you, set it as SITE_URL in `src/config.mjs`
   (edit the file on GitHub), and it redeploys automatically.
Cloudflare cannot run an Astro project straight from a zip: the site has to be built first,
which the steps above do for you.
