// Cloudflare Worker. Only /api/* reaches this code; pages are static assets.
import products from '../src/data/products.json';
import { filterProducts, parseQuery, rank, formatNGN, AVAILABILITY_LABEL } from '../src/lib/catalogue.js';

// Check Cloudflare's Workers AI model list. Pick a model that is included in the free allocation.
const MODEL = '@cf/meta/llama-3.1-8b-instruct';

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });

export default {
  async fetch(request, env) {
    const { pathname } = new URL(request.url);
    if (pathname === '/api/concierge') {
      if (request.method !== 'POST') return json({ error: 'Use POST.' }, 405);
      return concierge(request, env);
    }
    return env.ASSETS.fetch(request);
  },
};

async function concierge(request, env) {
  let message = '';
  try {
    message = String((await request.json()).message || '').trim();
  } catch {
    return json({ error: 'Invalid request.' }, 400);
  }
  if (message.length < 2 || message.length > 300) return json({ error: 'Please write 2 to 300 characters.' }, 400);

  // 1. Code decides which products qualify. The AI never picks products or prices.
  const criteria = parseQuery(message);
  const pool = filterProducts(products, { maxPrice: criteria.maxPrice, minPrice: criteria.minPrice });
  const matches = rank(pool, criteria.terms).slice(0, 4).map((p) => ({
    name: p.name,
    url: `/piece/${p.slug}/`,
    price: formatNGN(p.priceNGN),
    status: AVAILABILITY_LABEL[p.availability],
    summary: p.shortDescription,
  }));

  if (!matches.length) {
    return json({
      reply: 'No watches in the collection match that request yet. Try a different budget, or browse everything.',
      products: [],
      ai: false,
    });
  }

  // 2. The AI only words a short explanation of results it was handed.
  let reply = `Here ${matches.length === 1 ? 'is 1 watch' : `are ${matches.length} watches`} that fit your request.`;
  let ai = false;
  try {
    const run = env.AI.run(MODEL, {
      max_tokens: 160,
      messages: [
        {
          role: 'system',
          content:
            'You are the shopping concierge for TROTIE MAISON, a watch shop. Use ONLY the products in the JSON. ' +
            'Never state a price, specification, material or availability that is not in the JSON. ' +
            'Never say an order was placed. Write 2 short sentences explaining why these watches suit the request. ' +
            'Do not list prices; the page shows them.',
        },
        { role: 'user', content: `Customer request: ${message}\nProducts: ${JSON.stringify(matches)}` },
      ],
    });
    const result = await Promise.race([run, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000))]);
    const text = String(result?.response || '').trim().slice(0, 600);
    if (text) {
      reply = text;
      ai = true;
    }
  } catch {
    // Quota used up, timeout or network error: fall back to the plain reply above.
  }
  return json({ reply, products: matches, ai });
}
