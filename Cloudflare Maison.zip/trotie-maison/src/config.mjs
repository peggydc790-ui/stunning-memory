// Replace SITE_URL with your real workers.dev address after the first deploy.
export const SITE_URL = 'https://trotie-maison.YOUR-SUBDOMAIN.workers.dev';
// Taken from the WhatsApp link on the old site. Digits only, with country code.
export const WHATSAPP_NUMBER = '2347011838440';
export const BRAND = { name: 'TROTIE MAISON', slogan: 'Made for the top member' };
