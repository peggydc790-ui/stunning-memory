import { readFileSync } from 'node:fs';
import { validate } from '../src/lib/catalogue.js';

const products = JSON.parse(readFileSync(new URL('../src/data/products.json', import.meta.url), 'utf8'));
const { errors, warnings } = validate(products);
warnings.forEach((w) => console.warn('warning:', w));
errors.forEach((e) => console.error('ERROR:  ', e));
console.log(`${products.length} products checked: ${errors.length} errors, ${warnings.length} warnings`);
process.exit(errors.length ? 1 : 0);
